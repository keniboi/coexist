before you open Alpha, please turn off anti virus or whitelist it, thank you

After you open Alpha, go to settings and click "Download Elec" it might take 40+ seconds...
//you cant inject ElectronDLL.dll if you dont do the above ^



THANKS FOR READING
Cheers, Keni